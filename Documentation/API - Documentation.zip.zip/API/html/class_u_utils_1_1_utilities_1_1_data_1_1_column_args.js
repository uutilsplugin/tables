var class_u_utils_1_1_utilities_1_1_data_1_1_column_args =
[
    [ "ColumnArgs", "class_u_utils_1_1_utilities_1_1_data_1_1_column_args.html#a1ce4ae44b7cdcd4b878e3093763e4e12", null ],
    [ "Column", "class_u_utils_1_1_utilities_1_1_data_1_1_column_args.html#a72f593549889ace4c635e04f102332dd", null ]
];