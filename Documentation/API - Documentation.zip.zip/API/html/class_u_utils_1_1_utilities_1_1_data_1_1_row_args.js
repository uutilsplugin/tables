var class_u_utils_1_1_utilities_1_1_data_1_1_row_args =
[
    [ "RowArgs", "class_u_utils_1_1_utilities_1_1_data_1_1_row_args.html#ac8cd819ae01ac86d30806adbbb7bdc9d", null ],
    [ "Row", "class_u_utils_1_1_utilities_1_1_data_1_1_row_args.html#af568f8b6a2a052cfab1567014520d7eb", null ]
];