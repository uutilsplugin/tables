var hierarchy =
[
    [ "EditorWindow", null, [
      [ "UUtils.Utilities.Data.EditorWindowTable", "class_u_utils_1_1_utilities_1_1_data_1_1_editor_window_table.html", null ]
    ] ],
    [ "EventArgs", null, [
      [ "UUtils.Utilities.Data.ColumnArgs", "class_u_utils_1_1_utilities_1_1_data_1_1_column_args.html", null ],
      [ "UUtils.Utilities.Data.LogArgs", "class_u_utils_1_1_utilities_1_1_data_1_1_log_args.html", null ],
      [ "UUtils.Utilities.Data.RowArgs", "class_u_utils_1_1_utilities_1_1_data_1_1_row_args.html", null ],
      [ "UUtils.Utilities.Data.TableArgs", "class_u_utils_1_1_utilities_1_1_data_1_1_table_args.html", null ]
    ] ],
    [ "ISerializationCallbackReceiver", null, [
      [ "UUtils.Utilities.Data.EditorWindowTable", "class_u_utils_1_1_utilities_1_1_data_1_1_editor_window_table.html", null ]
    ] ],
    [ "UUtils.Utilities.Data.ITableColumn", "interface_u_utils_1_1_utilities_1_1_data_1_1_i_table_column.html", [
      [ "UUtils.Utilities.Data.TableColumn", "class_u_utils_1_1_utilities_1_1_data_1_1_table_column.html", null ]
    ] ],
    [ "UUtils.Utilities.Data.ITableRowValue", "interface_u_utils_1_1_utilities_1_1_data_1_1_i_table_row_value.html", [
      [ "UUtils.Utilities.Data.TableRowValue", "class_u_utils_1_1_utilities_1_1_data_1_1_table_row_value.html", null ]
    ] ],
    [ "ScriptableObject", null, [
      [ "UUtils.Utilities.Data.TableSO", "class_u_utils_1_1_utilities_1_1_data_1_1_table_s_o.html", null ]
    ] ],
    [ "UUtils.Utilities.Data.Table", "class_u_utils_1_1_utilities_1_1_data_1_1_table.html", null ],
    [ "UUtils.Utilities.Data.TableRow", "class_u_utils_1_1_utilities_1_1_data_1_1_table_row.html", null ]
];