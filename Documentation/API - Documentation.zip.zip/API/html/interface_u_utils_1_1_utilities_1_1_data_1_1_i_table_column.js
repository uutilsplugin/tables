var interface_u_utils_1_1_utilities_1_1_data_1_1_i_table_column =
[
    [ "GetRowByValue", "interface_u_utils_1_1_utilities_1_1_data_1_1_i_table_column.html#a0da463f9797bc443803dcbb1d6891031", null ],
    [ "GetRows", "interface_u_utils_1_1_utilities_1_1_data_1_1_i_table_column.html#a0978c3bf1ee2d91b6027180a8db930b3", null ],
    [ "GetRowValue", "interface_u_utils_1_1_utilities_1_1_data_1_1_i_table_column.html#aba469f14a604ad5fc52d67fdaab5eee3", null ],
    [ "ColumnName", "interface_u_utils_1_1_utilities_1_1_data_1_1_i_table_column.html#a1ae9df32b1a598ddc9fe98a90c92212f", null ],
    [ "Index", "interface_u_utils_1_1_utilities_1_1_data_1_1_i_table_column.html#a659a5287ebbde8c413e6c1984b857840", null ],
    [ "RowCount", "interface_u_utils_1_1_utilities_1_1_data_1_1_i_table_column.html#a5bf1c243ccceeaff4c7f7edbacde07fa", null ],
    [ "OnColumnNameUpdate", "interface_u_utils_1_1_utilities_1_1_data_1_1_i_table_column.html#a452ecba51d2beb123a5114abbcc8c7dd", null ]
];