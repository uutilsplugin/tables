var searchData=
[
  ['addtablerow',['AddTableRow',['../class_u_utils_1_1_utilities_1_1_data_1_1_table_column.html#a2bad28c1c75ae1a3df9953ab407720f5',1,'UUtils.Utilities.Data.TableColumn.AddTableRow(string _value)'],['../class_u_utils_1_1_utilities_1_1_data_1_1_table_column.html#a04221e870399db1e0f847a7524913477',1,'UUtils.Utilities.Data.TableColumn.AddTableRow(string _value, int _index)']]]
];
