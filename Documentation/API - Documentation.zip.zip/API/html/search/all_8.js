var searchData=
[
  ['name',['Name',['../class_u_utils_1_1_utilities_1_1_data_1_1_table.html#a530c38c9d123ab08f8e68842a6bd042b',1,'UUtils::Utilities::Data::Table']]],
  ['newcolumnname',['newColumnName',['../class_u_utils_1_1_utilities_1_1_data_1_1_editor_window_table.html#a90204ab23076cea7fe7ccae13953a304',1,'UUtils::Utilities::Data::EditorWindowTable']]]
];
