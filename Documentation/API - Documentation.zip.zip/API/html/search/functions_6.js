var searchData=
[
  ['insertrow',['InsertRow',['../class_u_utils_1_1_utilities_1_1_data_1_1_table.html#a0253ea577fd62bbf26a8d55a037badea',1,'UUtils.Utilities.Data.Table.InsertRow()'],['../class_u_utils_1_1_utilities_1_1_data_1_1_table.html#ad3792019ed5c40255fa4484011a8238a',1,'UUtils.Utilities.Data.Table.InsertRow(int _index)']]],
  ['interfacesave',['InterfaceSave',['../class_u_utils_1_1_utilities_1_1_data_1_1_editor_window_table.html#adb0c7a91a436a870bdf07702c5de7843',1,'UUtils::Utilities::Data::EditorWindowTable']]]
];
