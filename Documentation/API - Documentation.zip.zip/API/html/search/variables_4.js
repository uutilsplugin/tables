var searchData=
[
  ['optionsperpageint',['optionsPerPageInt',['../class_u_utils_1_1_utilities_1_1_data_1_1_editor_window_table.html#a52621c4161f0dc600895d0cbe4427310',1,'UUtils::Utilities::Data::EditorWindowTable']]],
  ['optionsperpagestring',['optionsPerPageString',['../class_u_utils_1_1_utilities_1_1_data_1_1_editor_window_table.html#a746dbeb479752d64fcc26a63b3176e81',1,'UUtils::Utilities::Data::EditorWindowTable']]]
];
